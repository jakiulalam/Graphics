#include<stdlib.h>
#include<windows.h>
#include<GL/glut.h>
#include<math.h>

void myDisplay(void)
{

    float length;
    float x1=100;
    float y1=200;
    float x2=200;
    float y2=300;
    float x=x1;
    float y=y1;

    length=abs(x2-x1);
    if(abs(y2-y1)>length)
    {
        length=abs(y2-y1);
    }

    float x_inc= (x2-x1)/length;
    float y_inc= (y2-y1)/length;

   // x=x+0.5;
   // y=y+0.5;

    for(int i=1;i<=length;i++)
    {
        glBegin(GL_POINTS);
        glVertex2i(round(x),round(y));
        glEnd();

        x=x+x_inc;
        y=y+y_inc;

    }



glFlush ();
}

void myInit (void)
{
glClearColor(1.0, 1.0, 1.0, 0.0);
glColor3f(0.0f, 0.0f, 0.0f);
glPointSize(4.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0.0, 400.0, 0.0, 400.0);
}

int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (400, 400);
glutInitWindowPosition (100, 100);
glutCreateWindow ("my first attempt");
glutDisplayFunc(myDisplay);
myInit ();
glutMainLoop();
}

