#include <Gl/gl.h>
#include <GL/glut.h>
void myInit();
void myDisplay();


void myDisplay(void)
{
glClear (GL_COLOR_BUFFER_BIT);
glColor3f (255.0, 255.0, 0.0);
glPointSize(5.0);


glBegin(GL_POLYGON);

glVertex2i(10, 20);
glVertex2i(10, 160);
glVertex2i(200, 160);
glVertex2i(200, 20);
glEnd();

glColor3f (0.0, 0.0, 0.0);
glPointSize(5.0);



glBegin(GL_POLYGON);

glVertex2i(30, 30);
glVertex2i(30, 130);
glVertex2i(50, 130);
glVertex2i(50, 30);



glEnd();


glColor3f (0.0, 0.0, 0.0);
glPointSize(5.0);

glBegin(GL_POINTS);

glVertex2i(30, 30);
glVertex2i(30, 50);
glVertex2i(90, 50);
glVertex2i(90, 30);



glEnd();




glColor3f (1.0, 0.0, 0.0);
glPointSize(5.0);


glBegin(GL_POLYGON);

glVertex2i(120, 30);

glVertex2i(110, 40);

glVertex2i(100, 50);

glVertex2i(90, 60);

glVertex2i(80, 70);
glVertex2i(80, 120);
glVertex2i(90, 120);
glVertex2i(90, 130);
glVertex2i(120, 130);
glVertex2i(120, 120);
glVertex2i(140, 120);
glVertex2i(140, 130);
glVertex2i(170, 130);
glVertex2i(170, 120);
glVertex2i(180, 120);
glVertex2i(180, 70);

glVertex2i(170, 60);

glVertex2i(160, 50);

glVertex2i(150, 40);

glVertex2i(140, 30);

glEnd();

glColor3f (0.0, 0.0, 0.0);
glPointSize(5.0);



glFlush ();
}
void myInit (void)
{
glClearColor(1.0, 1.0, 1.0, 0.0);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
gluOrtho2D(0.0, 640.0, 0.0, 480.0);
}



int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (640, 480);
glutInitWindowPosition (200, 150);
glutCreateWindow ("love");
glutDisplayFunc(myDisplay);
myInit ();
glutMainLoop();
}
