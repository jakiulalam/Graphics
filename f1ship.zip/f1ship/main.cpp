#include<GL/gl.h>
#include <GL/glut.h>

float transFactor = 0.0f;
float getX(int val)
{
    int width = glutGet(GLUT_WINDOW_WIDTH);
    float frac = (float)val/((float)width/2);
    return frac;
}
float getY(int val)
{
    int height = glutGet(GLUT_WINDOW_HEIGHT);
    float frac = (float)val/((float)height/2);
    return frac;
}
void drawScene()

{
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
        glTranslatef(transFactor,0,0);

        glColor3ub(56,83,173);
        glBegin(GL_QUADS);
            glVertex2f(getX(-400),getY(50));
            glVertex2f(getX(320),getY(50));
            glVertex2f(getX(250),getY(-50));
            glVertex2f(getX(-350),getY(-50));
            glEnd();

        glColor3ub(73,73,73);
        glBegin(GL_QUADS);
            glVertex2f(getX(-340),getY(110));
            glVertex2f(getX(220),getY(110));
            glVertex2f(getX(220),getY(50));
            glVertex2f(getX(-340),getY(50));
            glEnd();

        glColor3ub(182,182,182);
        glBegin(GL_QUADS);
            glVertex2f(getX(-300),getY(200));
            glVertex2f(getX(-220),getY(200));
            glVertex2f(getX(-220),getY(110));
            glVertex2f(getX(-300),getY(110));
            glEnd();

        glColor3ub(182,182,182);
        glBegin(GL_QUADS);
            glVertex2f(getX(-180),getY(230));
            glVertex2f(getX(-100),getY(230));
            glVertex2f(getX(-100),getY(110));
            glVertex2f(getX(-180),getY(110));
            glEnd();

        glColor3ub(182,182,182);
        glBegin(GL_QUADS);
            glVertex2f(getX(-60),getY(260));
            glVertex2f(getX(20),getY(260));
            glVertex2f(getX(20),getY(110));
            glVertex2f(getX(-60),getY(110));
            glEnd();




    glPopMatrix();

    glColor3ub(111,173,223);
        glBegin(GL_QUADS);
            glVertex2f(getX(-400),getY(-50));
            glVertex2f(getX(400),getY(-50));
            glVertex2f(getX(400),getY(-400));
            glVertex2f(getX(-400),getY(-400));
            glEnd();

    glutSwapBuffers();

}

void update(int value)
{
    transFactor+=0.01f;
    if(transFactor>getX(400*2))
       transFactor = -1 * getX(400 * 2);
    glutPostRedisplay();
    glutTimerFunc(20,update,0);
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(800, 800);
	glutCreateWindow("Transformation");
	glutDisplayFunc(drawScene);
	glutTimerFunc(20,update,0);
	glutMainLoop();
	return 0;
}
