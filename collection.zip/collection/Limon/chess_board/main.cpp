#include <stdio.h>
#include<GL/gl.h>
#include <GL/glut.h>

int x=-200, y=200;


void myDisplay(void)
{
glClear (GL_COLOR_BUFFER_BIT);
glColor3f (0.0, 0.0, 0.0);

for(int i=0; i<8; i++)
{
    for(int j=0; j<8; j++)
    {
        if(i%2==0)
        {
            if((j%2==0))
            glColor3ub (255, 255, 255);
            else
            glColor3ub (0, 0, 0);
        }
        else
        {
            if((j%2==0))
            glColor3ub (0, 0, 0);
            else
            glColor3ub (255, 255, 255);
        }
        glBegin(GL_POLYGON);
        glVertex2i(x, y);
        glVertex2i(x, y-50);
        glVertex2i(x+50,y-50);
        glVertex2i(x+50, y);
        glEnd();
        x+=50;
    }
    x=-200;
    y-=50;
}
glFlush ();
}



void myInit (void)
{
glClearColor(1.0, 1.0, 1.0, 0.0);
glColor3f(0.0f, 0.0f, 0.0f);
glPointSize(4.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(-320.0, 320.0, -240.0, 240.0);
}
main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (640, 480);
glutInitWindowPosition (100, 150);
glutCreateWindow ("8x8 Chess Board");
glutDisplayFunc(myDisplay);
myInit ();
glutMainLoop();
}



