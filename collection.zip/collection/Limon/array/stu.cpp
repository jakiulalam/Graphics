#include <iostream>

using namespace std;


class Student
{

int id;
string name;
int credit;
 float cgpa;
public:
    void setValues(int i,string nm,float cg);
    void getValues()

    {

    cout <<"Enter ID:"<<id<<endl;
    cout <<"Enter Name:"<<name<<endl;
    cout<<"Credit"<<credit<<endl;
    cout <<"Enter CGPA:"<<cgpa<<endl;

    }


};
void Student::setValues(int i,string nm,float cg)
{
    id=i;
    name=nm;
    credit=c;
}   cgpa=cg;


int main()
{
    Student s1;
    int id,cr;
    string n;
    float res;

    for(i=0;i<50;i++)

    cout<<"Enter ID";
    cin>>id;
    cout<<"Enter Name";
    cin,ignore();
    getline(cin,n);
    cout<<"Enter Credit:";
    cin>>cr;
    cout<<"Enter CGPA";
    cin>>res;
     s[i].setValues(id,n,cr,res)
}

cout<<endl;
for(i=0;i<5;i++)
  {

  s[i].getValues();
   cout<<endl;
  }




