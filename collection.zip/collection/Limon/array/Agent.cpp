#include<bits/stdc++.h>
using namespace std;
#define n 3
int x[4]= {1,-1,0,0};
int y[4]= {0,0,1,-1};
int visit[n+1][n+1];
//int n=3;
int arr[n+1][n+1];


void dfs(int u,int v,int parent, int child)
{
    int p,q,i,j;
    if(!visit[u][v])
    {
        visit[u][v]=1;
        if(arr[u][v])
        {
            arr[u][v]=0;
            cout<<"clear ->"<<u<<" "<<v<<" ,"<<endl;
        }
        else
        {
            cout<<"nothing ->"<<u<<" "<<v<<" ,"<<endl;
        }

        for(i=0; i<4; i++)
        {
            p=(u+x[i]);
            q=(v+y[i]);
            if(p>n || q>n || p<=0 || q<=0)
            {
                continue;
            }
            if((x[i]==1 && !y[i] )&& !visit[p][q])
            {
                cout<<"Turn Down"<<endl;
                dfs(p,q,u,v);
            }
            if((x[i]==-1 && !y[i])&& !visit[p][q])
            {
                cout<<"Turn  Up"<<endl;;
                 dfs(p,q,u,v);
            }

            if((!x[i] && y[i]==1)&& !visit[p][q])
            {
                cout<<"Turn Right"<<endl;;
                dfs(p,q,u,v);
            }
            if((!x[i] && y[i]==-1)&& !visit[p][q])
            {
                cout<<"Turn Left"<<endl;;
                 dfs(p,q,u,v);

            }

        }
    }

}


void create()
{
    int i,j;
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
        {
            arr[i][j]=rand()%2;
        }


    }


}

void  print()
{
    int i, j;
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }

}


int main()
{
    int t,u,v,i,j,k=0;
    cin>>t;
    while(t--)
    {
        k++;
        cout<<k<<" -> "<<endl;
        memset(visit,0,sizeof visit);
        create();
        print();
        cin>>u>>v;
        dfs(u,v,u,v);
        print();
        cout<<"------------"<<endl;


    }



}



