#include<bits/stdc++.h>
using namespace std;
struct node
{
    string location;
    string status;
    node ()
    {
        location="";
        status="";
    }

    bool operator<(const node &a)  const
    {
     return status.size()<a.status.size();
    }

};

map<node,string>mymap;

string Reflex_Vacuum_Agent(string location,string status)
{
    node temp;
    temp.location=location;
    temp.status=status;
    return mymap[temp];

}


string Reflex_Vacuum_Agenttemp(string location,string status)
{
    if(status=="Dirty")
    {
        return "Suck";
    }
    else if(location=="A")
    {
        return "Right";
    }
   return "Left";
}



void create()
{

    node temp;

    temp.location="A";
    temp.status="Dirty";
    mymap[temp]="Suck";
    // cout<<mymap[temp]<<endl;
//    node temp;

    temp.location="B";
    temp.status="Dirty";
    mymap[temp]="Suck";

    // node temp;

    temp.location="A";
    temp.status="Clean";
    mymap[temp]="Right";

    //  node temp;

    temp.location="B";
    temp.status="Clean";
    mymap[temp]="Left";




}
int main()
{
    create();
    string location,status,ans;
    cin>>location>>status;
    ans=Reflex_Vacuum_Agenttemp(location,status);
    cout<<ans<<endl;


}
