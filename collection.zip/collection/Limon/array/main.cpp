#include <iostream>

using namespace std;


class Student
{

int id;
string name;
float cgpa;
public:
    void setValues(int i,string nm,float cg);
    void getValues()

    {

    cout <<"Enter ID:"<<id<<endl;
    cout <<"Enter Name:"<<name<<endl;
    cout <<"Enter CGPA:"<<cgpa<<endl;

    }


};
void Student::setValues(int i,string nm,float cg)
{
    id=i;
    name=nm;
    cgpa=cg;
}

int main()
{
    Student s1;
    s1.setValues(23,"tithi",3.8);
    s1.getValues();
}
