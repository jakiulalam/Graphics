#include <stdio.h>
#include<GL/gl.h>
#include <GL/glut.h>
void myDisplay();
void myInit();
int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (490, 490);
glutInitWindowPosition (100, 150);
glutCreateWindow ("Zaman Chess Board");
glutDisplayFunc(myDisplay);
myInit ();
glutMainLoop();
return 0;
}
void myDisplay(void)
{
glClear (GL_COLOR_BUFFER_BIT);
glColor3f (0.0, 0.0, 0.0);
glPointSize(4.0);
glBegin(GL_QUADS);
for(int y=0; y<=490; y+=140)
for(int x=0; x<=490; x+=140)
{
    glVertex2i(y,x);
    glVertex2i(y+70,x);
    glVertex2i(y+70,x+70);
    glVertex2i(y,x+70);

}
for(int y=70; y<=490; y+=140)
for(int x=70; x<=490; x+=140)
{
    glVertex2i(y,x);
    glVertex2i(y+70,x);
    glVertex2i(y+70,x+70);
    glVertex2i(y,x+70);

}
glEnd();
glFlush ();
}
void myInit (void)
{
glClearColor(1.0, 1.0, 1.0, 0.0);
glColor3f(0.0f, 0.0f, 0.0f);
glPointSize(4.0);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
gluOrtho2D(0.0, 490.0, 0.0, 490.0);
}
