#include<iostream>

using namespace std;

int binarySearch(int arr[10], int n, int value)
{
    int first = 0, last = 9,middle;
    while ( first <= last )
        { middle = (first + last) / 2;
      if (arr[middle] == value)
      return middle;
    else if (arr[middle] > value)
        last = middle - 1;
    else    first = middle + 1;
     }
     return -1;
     }


int main()
{
  int i,j,temp;
  int arr[]={2,4,6,10,5,7,3,9,8,1};
    for(i=0;i<9;i++)
    {
        for(j=i+1;j<10;j++)
        {
            if(arr[i]>arr[j])
            {
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
        }
    }
    int n,position;
    cout<<"Enter the target value: ";
    cin>>n;
  position=binarySearch(arr,10,n);
    if(position==-1)
    cout<<"NOT FOUND";
    else cout<<"position is :"<<position;
}

