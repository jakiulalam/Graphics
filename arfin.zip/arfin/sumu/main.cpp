#include<iostream>
using namespace std;
int main(){
int  n,temp,A[10];
for(int i=0;i<10;i++)
{
    cin>>A[i];

}
for(int i=0;i<9;i++)
{
    for(int j=i+1;j<10;j++)
    {
       n=i;
        if(A[i]>A[j])
            n=j;
       {  temp=A[i];
          A[i]=A[n];
          A[n]=temp;}
    }
}


for(int i=0;i<10;i++)
{
    cout<<A[i]<<" ";
}
}
