#include<iostream>

using namespace std;

int linearSearch(int arr[5],int elements,int value)
{
    int index=0;
    int position=-1;
    bool found=false;

    while(index<elements && !found)
    {

        {
        if(arr[index]==value)
            found=true;
        position=index;
        }
    index++;
    }
    return position;

}

int main()
{
    int arr[5],position,n;
    cout<<"Enter the values : ";
    for(int i=0;i<5;i++)
    {
        cin>>arr[i];
    }

    cout<<"Enter target value : ";
    cin>>n;
    position=linearSearch(arr[5],5,n);
    cout<<position;

}
