#include <iostream>

using namespace std;

int main()
{
    int  A[30],n,i,j,temp,a[30];
    cout<<"enter the size of array:  ";
    cin>>n;
    cout<<"enter the elements of array: ";
    for (i=0;i<n;i++)
    {
        cin>>a[i];
    }

        for(i=1;i<n;++i)
    {
        for(j=0;j<(n-i);++j)
            if(a[j]>a[j+1])
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
            }
    }

    cout<<"Array after bubble sort:";
    for(i=0;i<n;++i)
        cout<<" "<<a[i];

    return 0;
}

