#include<iostream>
using namespace std;
int main()
{
    int i,n;
    cout<<"size of array";
    cin>>n;
    int a[n],flag=1;
    int high,low,mid;
    high=n;
    low=1;
    for(i=0;i<n;i++)
    {
        cin>>a[i];
    }
    int value;
    cout<<"value you want to find:";
    cin>>value;
    while(low!=high)
    {
        mid=(high+low)/2;
        if(a[mid]==value)
        {
            cout<<"value found";
            flag=0;
            break;
        }
        else if(value<a[mid])
        {
            high=mid+1;
        }
        else
        {
            low=mid+1;
        }
        if(flag==1)
        {
            cout<<"value not found";
        }
    }
    return 0;
}
