#include <iostream>

using namespace std;

int main()
{
    int number[45],i,j,n,temp;
    cout << "Input number: \n" << endl;
    cin>>n;

     cout << "Put Input : \n" << endl;
    for(i=0;i<n;i++)
    {
        cin>> number[i];
    }

    for(i=0; i<n; i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(number[i]>number[j])
            {
                temp=number[i];
                number[i]=number[j];
                number[j]=temp;
            }
        }
    }

    int min=0,max=n,mid,e;

    cout<< "enter search element: \n";
    cin>>e;

    mid=(max+min)/2;

    while(min<max)    {
        if(number[mid]> e )
        {
            min=mid+1;
        }
        else if( number[mid]==e)
        {
            cout << "found at position: \t"<<mid<<endl;
            break;
        }
        else if(number[mid]< e)
        {
            max= mid-1;
        }
         mid=(max+min)/2;
    }

    if(min>max)
    {
        cout<<" not found."<<endl;
    }
    return 0;
}
