#include <GL/gl.h>
#include <GL/glut.h>
void myDisplay()
{
glClear (GL_COLOR_BUFFER_BIT);
glColor3f (1.0, 0.0, 0.0);
glPointSize(5.0);
glBegin(GL_LINE_LOOP);
glVertex2i(200, 200);
glVertex2i(600, 200);
glVertex2i(600, 400);
glVertex2i(200, 400);
glEnd();
glFlush ();
}
void myInit ()
{
glClearColor(0.45,0.75, 0.75, 0.0);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
gluOrtho2D(0.0, 640.0, 0.0, 480.0);
}

main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (640, 480);
glutInitWindowPosition (200, 150);
glutCreateWindow ("Hello World");
glutDisplayFunc(myDisplay);
myInit ();
glutMainLoop();
}
