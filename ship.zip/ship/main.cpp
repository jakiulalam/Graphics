#include <GL/gl.h>
#include <GL/glut.h>

void myDisplayB()
{
glClear (GL_COLOR_BUFFER_BIT);
glColor3f (0.45,0.45,0.45);
glPointSize(5.0);
glBegin(GL_POLYGON);
glVertex2i(350, 250);
glVertex2i(250, 430);
glVertex2i(850,430);
glVertex2i(700, 250);
glEnd();
///piler1
glColor3f (0.188, 0.188, 0.188);
glBegin(GL_POLYGON);
glVertex2i(350, 430);
glVertex2i(350, 550);
glVertex2i(400,550);
glVertex2i(400, 430);
glEnd();
///shadow1
glColor3f (0.244, 0.244, 0.244);
glBegin(GL_POLYGON);
glVertex2i(360, 570);
glVertex2i(360, 590);
glVertex2i(390,590);
glVertex2i(390, 570);
glEnd();
///shadow2
glBegin(GL_POLYGON);
glVertex2i(370,600);
glVertex2i(370, 620);
glVertex2i(400,620);
glVertex2i(400, 600);
glEnd();
///shadow3
glBegin(GL_POLYGON);
glVertex2i(380,630);
glVertex2i(380, 650);
glVertex2i(410,650);
glVertex2i(410, 630);
glEnd();

///piler2
glColor3f (0.188, 0.188, 0.188);
glBegin(GL_POLYGON);
glVertex2i(500, 430);
glVertex2i(500, 650);
glVertex2i(550, 650);
glVertex2i(550, 430);
glEnd();
///shadow1
glColor3f (0.244, 0.244, 0.244);
glBegin(GL_POLYGON);
glVertex2i(510, 670);
glVertex2i(510, 690);
glVertex2i(540, 690);glColor3f (0.244, 0.244, 0.244);
glVertex2i(540, 670);
glEnd();
///shadow2
glBegin(GL_POLYGON);
glVertex2i(520,700);
glVertex2i(520, 720);
glVertex2i(550, 720);
glVertex2i(550, 700);
glEnd();
///shadow3
glBegin(GL_POLYGON);
glVertex2i(530,730);
glVertex2i(530, 750);
glVertex2i(560, 750);
glVertex2i(560, 730);glColor3f (0.244, 0.244, 0.244);
glEnd();

///piler3
glColor3f (0.188, 0.188, 0.188);
glBegin(GL_POLYGON);
glVertex2i(650, 430);
glVertex2i(650, 610);
glVertex2i(700, 610);
glVertex2i(700, 430);
glEnd();
///shadow1
glColor3f (0.244, 0.244, 0.244);
glBegin(GL_POLYGON);
glVertex2i(660, 630);
glVertex2i(660, 650);glColor3f (0.244, 0.244, 0.244);
glVertex2i(690, 650);
glVertex2i(690, 630);
glEnd();
///shadow2
glBegin(GL_POLYGON);
glVertex2i(670,670);
glVertex2i(670, 690);
glVertex2i(700,690);
glVertex2i(700, 670);
glEnd();
///shadow3
glBegin(GL_POLYGON);
glVertex2i(680,710);
glVertex2i(680, 730);
glVertex2i(710, 730);
glVertex2i(710, 710);
glEnd();


glFlush ();
}

void myInit ()
{
    glClearColor(1.0,1.0, 1.0, 0.0);
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();
gluOrtho2D(0.0, 1024.0, 0.0, 768.0);
}


main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);


glutInitWindowSize (1024, 768);
glutInitWindowPosition (0, 0);
glutCreateWindow ("Ship_Assignment");
glutDisplayFunc(myDisplayB);
myInit ();
glutMainLoop();
}
